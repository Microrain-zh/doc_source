
#include "main.h"

volatile int a = 123;

struct dog {
	char sex;
	int age;
};


int mymain()
{

	volatile int *p;
	
	p= 0x20001000;
	
	*p = 1234;
	
	return 0;
}
