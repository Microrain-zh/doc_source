
#include "main.h"

int add_val(int v)
{
	volatile  int a = v;
	a++;
	return a;
}

void copy_add_val_to_ram(void)
{
	unsigned char *src;
	unsigned int val = (unsigned int)add_val;
	unsigned char *dest = (unsigned char *)0x20008000;
	
	int i;
	
	src = (unsigned char *)(val & ~1);
	
	for (i = 0; i < 16; i++)
	{
		dest[i] = src[i];
	}
}

int mymain()
{
	volatile int a = 1;	
	int (*f)(int v);
	
	a = add_val(a);
	
	
	
	copy_add_val_to_ram();
	
	f = (int (*)(int v))0x20008001;
	a = f(a);
	
	a = add_val(a);
	
	return 0;
}
